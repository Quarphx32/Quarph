# Quarph Bot

## Bu Bot Ne İşe Yarar?
**Quarph Bot**, Discord sunucularında toplu kanal oluşturma, toplu kanal/rol silme ve otomatik spam mesaj gönderme işlemlerini hızlı ve otomatik şekilde yapar.
Özellikle test, stres, deneme veya sunucu sıfırlama gibi işlemler için kullanılır.

### Temel Özellikler:
- Sunucudaki tüm kanalları ve rolleri topluca siler.
- Saniyede toplu şekilde yeni kanallar açar.
- Her açılan kanalda otomatik olarak belirlediğin mesajı (`@everyone`) sürekli spamlar.
- Kullanıcı dostu bir arayüz ile (batch dosyası) kolayca başlatılır ve yönetilir.

> **UYARI:**  
> Bu bot, sunucuda büyük değişiklikler yapar ve spam atar.  
> Sadece kendi test sunucularında ve izinli ortamlarda kullanmalısın.  
> Kötüye kullanım Discord kurallarına aykırıdır ve hesabın banlanabilir.

## Kurulum
1. Node.js ve npm yüklü olmalı.
2. Proje klasöründe terminal aç:
   ```bash
   npm install
   ```
3. `.env` dosyasını oluştur ve aşağıdaki gibi doldur:
   ```
   TOKEN=discord_bot_tokenin
   OWNER_ID=senin_discord_id
   LOG_CHANNEL_ID=log_kanal_id
   ```

## Kullanım
1. `fck.bat` dosyasını çift tıkla veya terminalde:
   ```bash
   fck.bat
   ```
2. Açılan ekranda:
   - Sunucu ID'sini gir
   - Komut olarak `fckall` yaz

## Katkıda Bulunma
Bu proje açık kaynak kodludur ve geliştirmeye açıktır. Projeye katkıda bulunmak için:

1. Bu depoyu fork edin
2. Yeni bir branch oluşturun (`git checkout -b feature/yeniOzellik`)
3. Değişikliklerinizi commit edin (`git commit -am 'Yeni özellik: Açıklama'`)
4. Branch'inizi push edin (`git push origin feature/yeniOzellik`)
5. Pull Request oluşturun

### Geliştirme Ortamı
Projeyi geliştirmek için:

1. Gerekli bağımlılıkları yükleyin:
   ```bash
   npm install
   ```

2. `.env` dosyasını oluşturun:
   ```
   TOKEN=test_bot_tokenin
   OWNER_ID=senin_discord_id
   LOG_CHANNEL_ID=log_kanal_id
   ```

3. Geliştirme modunda çalıştırın:
   ```bash
   node bot.js
   ```

### Kod Standartları
- Kod yazarken ESLint kurallarına uyun
- Her yeni özellik için test yazın
- Değişikliklerinizi açıklayan commit mesajları yazın
- Pull Request'lerinizde değişikliklerinizi detaylı açıklayın

### Yeni Özellik Önerileri
Yeni özellik önerileri için:
1. GitHub Issues bölümünde yeni bir issue açın
2. Önerinizi detaylı bir şekilde açıklayın
3. Varsa örnek kod veya kullanım senaryoları ekleyin

## Lisans
Bu proje MIT Lisansı ile lisanslanmıştır - detaylar için [LICENSE](LICENSE) dosyasına bakın.

### Bağımlılıklar ve Lisansları
Bu proje aşağıdaki açık kaynak kütüphaneleri kullanmaktadır:
- [discord.js](https://github.com/discordjs/discord.js) - MIT Lisansı
- [dotenv](https://github.com/motdotla/dotenv) - BSD-2-Clause Lisansı

Bu bağımlılıkların lisansları hakkında daha fazla bilgi için lütfen ilgili GitHub depolarını ziyaret edin.
